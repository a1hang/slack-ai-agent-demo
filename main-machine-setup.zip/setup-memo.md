# Slack AI Agent Demo - セットアップメモ

## メインマシンでの初回セットアップ手順

### 1. CDKブートストラップ

```bash
# 管理者権限プロファイルでCDKブートストラップ
export AWS_PROFILE=admin-profile
npm run bootstrap
```

### 2. 初回デプロイ

```bash
# IAMリソース作成を含む初回デプロイ
npm run deploy
```

**デプロイ後の出力情報をメモ：**
- API Gateway URL: `https://[api-id].execute-api.ap-northeast-1.amazonaws.com/prod/`
- Slack Events URL: `https://[api-id].execute-api.ap-northeast-1.amazonaws.com/prod/slack/events`

### 3. 開発マシン用IAMユーザー作成

```bash
# IAMユーザー作成
aws iam create-user --user-name slack-ai-agent-demo-dev

# IAMポリシー作成
aws iam create-policy \
  --policy-name SlackAiAgentDemoDevPolicy \
  --policy-document file://tmp/dev-policy.json

# ポリシーをユーザーにアタッチ
aws iam attach-user-policy \
  --user-name slack-ai-agent-demo-dev \
  --policy-arn arn:aws:iam::[ACCOUNT-ID]:policy/SlackAiAgentDemoDevPolicy

# アクセスキー作成
aws iam create-access-key --user-name slack-ai-agent-demo-dev
```

**出力されたアクセスキー情報を `tmp/dev-credentials.env` に保存**

### 4. Slackアプリ設定

1. Slack APIでアプリ作成
2. Bot Token Scopesに `chat:write` を追加
3. Event Subscriptionsを有効化
4. Request URLに上記のSlack Events URLを設定
5. Bot Eventsに `message.channels` を追加
6. Slack トークンを `tmp/dev-credentials.env` に追加

## 開発マシンへの情報共有

以下のファイルをBitwardenで共有：
- `tmp/dev-credentials.env` - AWS認証情報とSlackトークン
- `tmp/deployment-outputs.txt` - デプロイ結果のURL情報
- このファイル（setup-memo.md）

## トラブルシューティング

問題が発生した場合は `tmp/troubleshooting.md` に記録する。