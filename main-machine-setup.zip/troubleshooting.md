# トラブルシューティング

## よくある問題と解決方法

### CDKデプロイ関連

#### 1. Bootstrap Error
```
Error: This stack uses assets, so the toolkit stack must be deployed to the environment
```
**解決方法**: `npm run bootstrap` を実行

#### 2. Permission Denied
```
User: xxx is not authorized to perform: cloudformation:CreateStack
```
**解決方法**: 管理者権限のAWSプロファイルを使用

### Slack連携関連

#### 1. Event Subscription Verification Failed
**症状**: SlackのEvent SubscriptionでURLが検証できない
**解決方法**: 
- Lambda関数がデプロイされているか確認
- API Gateway URLが正しいか確認
- Slack Signing Secretが正しく設定されているか確認

#### 2. Bot Token エラー
**症状**: `invalid_auth` エラー
**解決方法**:
- Bot TokenがchatWriteスコープを持っているか確認
- 環境変数 `SLACK_BOT_TOKEN` が正しく設定されているか確認

### 開発マシン権限関連

#### 1. UpdateStack Permission Error
**症状**: CloudFormationスタックの更新ができない
**解決方法**: 
- IAMポリシーが正しくアタッチされているか確認
- リソース名のパターンが一致しているか確認

## 問題解決時の記録

### [日付] 問題タイトル
**症状**: 
**原因**: 
**解決方法**: 
**備考**: 

---

*新しい問題が発生した場合は、上記フォーマットで記録してください*